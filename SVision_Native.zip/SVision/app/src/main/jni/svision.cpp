//
// Created by FKD on 2019/2/6.
//
#include <unistd.h>
#include <sys/types.h>
#include <dirent.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <dlfcn.h>

#include "svision.h"


int find_pid_of(const char *process_name) {
    int id;
    pid_t pid = -1;
    DIR* dir;
    FILE *fp;
    char filename[32];
    char cmdline[256];

    struct dirent * entry;

    if (process_name == NULL)
        return -1;

    dir = opendir("/proc");
    if (dir == NULL)
        return -1;

    while((entry = readdir(dir)) != NULL) {
        id = atoi(entry->d_name);
        if (id != 0) {
            sprintf(filename, "/proc/%d/cmdline", id);
            fp = fopen(filename, "r");
            if (fp) {
                fgets(cmdline, sizeof(cmdline), fp);
                fclose(fp);

                if (strcmp(process_name, cmdline) == 0) {
                    /* process found */
                    pid = id;
                    break;
                }
            }
        }
    }

    closedir(dir);
    return pid;
}

/**
 * 判断进程是否是APK进程
 * @return 0:apk;1:zygote;2:native
 */
int isAPKProcess(){
    int zygotePID=find_pid_of("zygote");
    int pid=getpid();
    int pPID=getppid();
    AKLog("this process PID:%d PPID:%d\n",pid,pPID);
    if(pid==zygotePID){//自身就是zygote(app_process)
        AKLog("we are in the zygote\n");
        return 1;
    }
    if(pPID==zygotePID){//是zygote的子进程
        AKLog("we are in the apk process\n");
        return 0;
    }
    AKLog("we are in the native process\n");
    return 2;
}

JNIEnv*(*getAndroidRuntimeEnv_SVision)();
JNIEnv* getJNIEnvByDLSYM() {
    void*runtime = dlopen("/system/lib/libandroid_runtime.so", RTLD_NOW);
    getAndroidRuntimeEnv_SVision= (JNIEnv*(*)())dlsym(runtime, "_ZN7android14AndroidRuntime9getJNIEnvEv");
    return getAndroidRuntimeEnv_SVision();
}

JavaVM* getJavaVMByJNIEnv(){
    JNIEnv *env=getJNIEnvByDLSYM();
    JavaVM *jvm=NULL;
    env->GetJavaVM(&jvm);//运行时任意位置获取JVM标准姿势
    return jvm;
}

jobject getApplicationJNI(){
    JNIEnv *env=getJNIEnvByDLSYM();
    //获取Application实例
    jclass atClass = env->FindClass("android/app/ActivityThread");
    jmethodID caMethod = env->GetStaticMethodID(atClass,"currentApplication","()Landroid/app/Application;");
    jobject thisApp = env->CallStaticObjectMethod(atClass,caMethod);
    return thisApp;
}

int stringIndexOfJNI(jstring u,jstring strToFind){
    JNIEnv *env=getJNIEnvByDLSYM();
    jclass stringClass=env->FindClass("java/lang/String");
    jmethodID indexOfMethod=env->GetMethodID(stringClass,"indexOf","(Ljava/lang/String;)I");
    int result=env->CallIntMethod(u,indexOfMethod,strToFind);
    AKLog("indexOf result:%d\n",result);
    return result;
}

extern "C" JNIEXPORT jint JNICALL Java_com_pvdnc_psvision_hooktarget_Native_stringIndexOfJNI(JNIEnv *env,jobject thiz,jstring u,jstring strToFind){
    return stringIndexOfJNI(u,strToFind);
}

jstring getPackageNameJNI(){
    JNIEnv *env=getJNIEnvByDLSYM();
    jclass contextWClass=env->FindClass("android/content/ContextWrapper");
    jmethodID gpnMethod=env->GetMethodID(contextWClass,"getPackageName","()Ljava/lang/String;");
    jstring packageName=(jstring)(env->CallObjectMethod(getApplicationJNI(),gpnMethod));
    AKLog("packageName from JNI:%s\n",env->GetStringUTFChars(packageName,NULL));
    return packageName;
}

bool isNormalUser(){
    JNIEnv *env=getJNIEnvByDLSYM();
    int uid=getuid();
    int unUserID=uid-10000;
    if(unUserID<0){
        AKLog("this is a privitage user that we cannot care it\n");
        return false;
    }
    AKLog("this is a normal user we need to visit\n");
    char userNameBuf[1024];;
    int unLen=sprintf(userNameBuf,"u0_a%d",unUserID);
    jstring userName=env->NewStringUTF(userNameBuf);
    AKLog("tricky username:%s\n",env->GetStringUTFChars(userName,NULL));
    return true;
}

char* join(char *s1, char *s2) {
    char *result = (char*)(malloc(strlen(s1) + strlen(s2) + 1));//+1 for the zero-terminator
    //in real code you would check for errors in malloc here
    if (result == NULL) exit (1);
    strcpy(result, s1);
    strcat(result, s2);
    return result;
}

int sendBroadcastByAM(jstring action,jstring authAction){
    JNIEnv *env=getJNIEnvByDLSYM();
    setenv("CLASSPATH", "/system/framework/am.jar", 1);
    char* resultBDCmd="am broadcast --user 0 -a ";
    resultBDCmd=join(resultBDCmd, (char*)(env->GetStringUTFChars(action, NULL)));
    resultBDCmd=join(resultBDCmd," --es ");
    resultBDCmd=join(resultBDCmd,"pkgName ");
    resultBDCmd=join(resultBDCmd,(char*)(env->GetStringUTFChars(getPackageNameJNI(),NULL)));

    resultBDCmd=join(resultBDCmd," --es ");
    resultBDCmd=join(resultBDCmd,"authAction ");
    resultBDCmd=join(resultBDCmd,(char*)(env->GetStringUTFChars(authAction,NULL)));
    AKLog("resultBDCmd:%s\n",resultBDCmd);
    int ret=system(resultBDCmd);
    AKLog("send broadcast got a return code:%d\n",ret);
    //execv(bdCommand[0],bdCommand);
    return 0;
}

int checkUAResult() {
    JNIEnv *env = getJNIEnvByDLSYM();
    char *filePath = "/data/local/tmp/";
    filePath = join(filePath, "ua_");
    filePath = join(filePath, (char *) (env->GetStringUTFChars(getPackageNameJNI(), NULL)));
    AKLog("UAResult file path:%s\n",filePath);
    int result = 1;
    while (true) {//我知道这里有一个race condition绕过漏洞，但是我不会用lock
        FILE *fp = fopen(filePath, "r");
        if (fp == NULL)continue;//文件不存在，直接下一次循环
        fseek(fp, 0, SEEK_END);
        int len = (int)(ftell(fp));
        rewind(fp);
        AKLog("UAFile length:%d\n", len);
        char *fileData = new char[len + 1];
        fread(fileData, 1, len, fp);
        fileData[len] = 0;
        fclose(fp);
        AKLog("UAFile data:%s\n",fileData);
        jstring u = env->NewStringUTF(fileData);
        jstring strToFind = env->NewStringUTF("granted");
        if (stringIndexOfJNI(u, strToFind) >= 0)result = 0;//文件中存在granted，通过
        //(这里同样存在一个漏洞，可以通过getSystemService的name参数直接写入"granted"，然后发起race，复写UA文件实现绕过)
        break;
    }
    sendBroadcastByAM(env->NewStringUTF("com.pvdnc.svision.userauth.response"),
    env->NewStringUTF(filePath));//发送广播给daemon，通知daemon把这个UA文件删了
    return result;
}

int userAuth(jstring authAction) {
    JNIEnv *env = getJNIEnvByDLSYM();
    if(!isNormalUser())return 0;
    sendBroadcastByAM(env->NewStringUTF("com.pvdnc.svision.userauth.request"), authAction);
    return checkUAResult();
}


static bool isAppHooked;
void doSomeHook(){
    int psRetCode=isAPKProcess();
    if(psRetCode==2){//正处于native进程空间，什么也不做
        AKLog("we are in the wrong process space\n");
        return;
    }
    if(psRetCode==1){//正处于zygote进程空间，全局HOOK
        AKLog("we are in the zygote!!!\n");
        doInZygote();//这个代码目前有问题
        return;
    }
    if(isAppHooked){
        AKLog("it seems that thisApp has been hooked\n");
        return;
    }
    AKLog("start doSomeHook\n");
    JNIEnv *env=getJNIEnvByDLSYM();

    JavaVM *jvm=getJavaVMByJNIEnv();
    if (AKInitializeOnce(env,jvm) < JNI_OK) {//初始化AndHook框架
        AKLog("init AndHook failed\n");
        return;
    }
    AKLog("init AndHook finished");
    AKLog("start to hook getSystemService\n");
    doGetSystemServiceHook();
    AKLog("start to hook camera1Open\n");
    doCamera1OpenHook();
    AKLog("doSomeHook finished\n");
    isAppHooked=true;
}

extern "C" JNIEXPORT void JNICALL Java_com_pvdnc_psvision_svision_Native_doSomeHook(JNIEnv *env,jobject thiz){
    doSomeHook();
}

extern "C" JNIEXPORT int hook_entry(char* a){
    doSomeHook();
}




