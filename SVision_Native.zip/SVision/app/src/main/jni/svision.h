//
// Created by FKD on 2019/2/7.
//

#ifndef HOOKTARGET_SVISION_H
#define HOOKTARGET_SVISION_H

#endif //HOOKTARGET_SVISION_H

#include <jni.h>
#include "AndHook.h"
#include <android/log.h>

#define AKLog(...) __android_log_print(ANDROID_LOG_VERBOSE, __FUNCTION__, __VA_ARGS__)

JNIEnv* getJNIEnvByDLSYM();
JavaVM* getJavaVMByJNIEnv();

jobject getApplicationJNI();

jstring getPackageNameJNI();

char* join(char *s1, char *s2);

int stringIndexOfJNI(jstring u,jstring strToFind);

int userAuth(jstring authAction);


void doGetSystemServiceHook();
void doCamera1OpenHook();

void doInZygote();
void doSomeHook();
