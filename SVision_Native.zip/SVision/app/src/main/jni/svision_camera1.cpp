//
// Created by FKD on 2019/2/7.
//
#include "svision.h"
#include <stdio.h>
#include <stdlib.h>

static bool isCamera1Hooked;
static jmethodID old_Camera1OpenMethodID;
jobject myCamera1Open(JNIEnv* env_bak,jobject thiz,jint cameraIndex){
    JNIEnv *env=getJNIEnvByDLSYM();
    AKLog("invoked hooked camera1.Open with cameraIndex:%d\n",cameraIndex);
    char authAction[1024];;//这里有一个栈溢出漏洞，可以通过getSystemService提交一个超级长的cameraIndex参数，覆盖userAuth返回值
    //其实可以保留这种实现，就是利用系统下级方法对传入参数做检查（或者自己做检查，因为这些参数都有特殊意义）
    int aaLen=sprintf(authAction,"camera1Open#%d",cameraIndex);
    jstring authActionJStr=env->NewStringUTF(authAction);
    AKLog("authAction is:%s, length:%d\n",authAction,aaLen);
    if(userAuth(authActionJStr)!=0){//向上层发权限请求
        AKLog("user has denied its request\n");
        return NULL;
    }
    AKLog("user has granted its request\n");
    if(old_Camera1OpenMethodID!=NULL){//已经HOOK过了，调用原过程，给个返回
        AKLog("start to call old method");
        jclass camera1Class=env->FindClass("android/hardware/Camera");
        jobject targetService=env->CallStaticObjectMethod(camera1Class,old_Camera1OpenMethodID,cameraIndex);
        return targetService;
    }
    return NULL;
}

void doCamera1OpenHook(){
    JNIEnv *env=getJNIEnvByDLSYM();
    if(!isCamera1Hooked){
        AKLog("start hook camera1Open\n");
        jclass camera1Class=env->FindClass("android/hardware/Camera");
        AKJavaHookMethod(env,camera1Class,"open",
                         "(I)Landroid/hardware/Camera;",
                         reinterpret_cast<void *>(myCamera1Open),
                         &old_Camera1OpenMethodID/*原方法jMethodID，通过它访问未HOOK方法*/);
        isCamera1Hooked=true;
    }
}

