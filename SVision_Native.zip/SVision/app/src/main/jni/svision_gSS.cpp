//
// Created by FKD on 2019/2/7.
//
#include <stdio.h>
#include "svision.h"

static bool isGetSystemServiceHooked;
static jmethodID old_GetSystemServiceMethodID;
JNIEXPORT jobject JNICALL myGetSystemService(JNIEnv *env_bak,jobject thiz,jstring name){
    JNIEnv *env=getJNIEnvByDLSYM();
    AKLog("invoke hooked getSystemService with name:%s\n",
          env->GetStringUTFChars(name,NULL));

    char authAction[1024];//这里有一个栈溢出漏洞，可以通过getSystemService提交一个超级长的name参数，覆盖userAuth返回值
    //其实可以保留这种实现，就是利用系统下级方法对传入参数做检查（或者自己做检查，因为这些参数都有特殊意义）
    int aaLen=sprintf(authAction,"getSystemService#%s",
    env->GetStringUTFChars(name,NULL));
    jstring authActionJStr=env->NewStringUTF(authAction);
    AKLog("authAction is:%s, length:%d\n",authAction,aaLen);

    jstring cameraServiceName=env->NewStringUTF("camera");
    jstring locationServiceName=env->NewStringUTF("location");
    if(stringIndexOfJNI(name,cameraServiceName)>=0){//调用camera2API
        AKLog("user want to create a camera service\n");
        if(userAuth(authActionJStr)!=0){//鉴权
            AKLog("user has denied its request\n");
            return NULL;
        }
    }
    if(stringIndexOfJNI(name,locationServiceName)>=0){//调用定位服务
        AKLog("user want to create a location service\n");
        if(userAuth(authActionJStr)!=0){//鉴权
            AKLog("user has denied its request\n");
            return NULL;
        }
    }


    AKLog("user has granted its request\n");

    if(old_GetSystemServiceMethodID!=NULL){//已经HOOK过了，调用原过程，给个返回
        AKLog("start to call old method");
        jclass contextWClass=env->FindClass("android/content/ContextWrapper");
        jobject targetService=env->CallObjectMethod(getApplicationJNI(),old_GetSystemServiceMethodID,name);
        return targetService;
    }
    return NULL;
}

void doGetSystemServiceHook(){
    JNIEnv *env=getJNIEnvByDLSYM();
    if(!isGetSystemServiceHooked){
        AKLog("start hook getSystemService\n");
        jclass contextWClass=env->FindClass("android/content/ContextWrapper");
        AKJavaHookMethod(env,contextWClass,"getSystemService",
                         "(Ljava/lang/String;)Ljava/lang/Object;",
                         reinterpret_cast<void *>(myGetSystemService),
                         &old_GetSystemServiceMethodID/*原方法jMethodID，通过它访问未HOOK方法*/);
        isGetSystemServiceHooked=true;
    }
}



