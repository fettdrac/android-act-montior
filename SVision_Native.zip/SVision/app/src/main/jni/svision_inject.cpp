//
// Created by FKD on 2019/2/7.
//
#include <svision.h>
#include <dlfcn.h>

static bool isCallApplicationOnCreateHooked;
static jmethodID old_CallApplicationOnCreateMethodID;
void JNICALL myCallApplicationOnCreate(JNIEnv *env, jobject obj, jobject thisApp){
    if(old_CallApplicationOnCreateMethodID!=NULL){
        if(thisApp!=NULL){
            AKLog("thisApp address:%p\n",thisApp);
            doSomeHook();
        }
        env->CallVoidMethod(obj,old_CallApplicationOnCreateMethodID,thisApp);
    }
}

static bool isZygotyeHooked;
void doInZygote(){
    JNIEnv *env=getJNIEnvByDLSYM();
    JavaVM *jvm=getJavaVMByJNIEnv();
    if(isZygotyeHooked) {
        AKLog("it seems that zygote has been injected\n");
        return;
    }
    env->PushLocalFrame(128);
    if (AKInitializeOnce(env,jvm) < JNI_OK) {//初始化AndHook框架
        AKLog("init AndHook failed\n");
        return;
    }
    if(!isCallApplicationOnCreateHooked){
        AKLog("start hook callApplicationOnCreate\n");
        jclass instrumentationClass=env->FindClass("android/app/Instrumentation");
        if (instrumentationClass == NULL) {
            AKLog("it seems that this cannot work in parent zygote\n");
            env->ExceptionDescribe();
            env->ExceptionClear();
            return;
        } //if
        AKJavaHookMethod(env,instrumentationClass,"callApplicationOnCreate",
                         "(Landroid/app/Application;)V",
                         reinterpret_cast<void *>(myCallApplicationOnCreate),
                         &old_CallApplicationOnCreateMethodID/*原方法jMethodID，通过它访问未HOOK方法*/);
        AKLog("zygote hook finished oldCAOCMI address:%p\n",old_CallApplicationOnCreateMethodID);
        isCallApplicationOnCreateHooked=true;
        isZygotyeHooked=true;
    }
    env->PopLocalFrame(NULL);
}

