package com.pvdnc.psvision.asynctest;

import android.app.Application;
import android.content.Context;

public class AppContext {
    public static Context getAppContext() {
        Context context = null;
        try {
            Application application= (Application) Class.forName("android.app.ActivityThread").getMethod("currentApplication").invoke(null, (Object[]) null);
            context=application.getApplicationContext();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return context;
    }
}
