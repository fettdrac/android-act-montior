package com.pvdnc.psvision.asynctest;

import android.content.Context;
import android.util.Log;

public class AuthActionProcessor {
    public enum Result{
        Granted,Question,Deny
    }
    public enum Action {
        camera1Open,getSystemService
    }
    private static final String aaSplitTag="#";
    private Action action;
    private String extraInfo;
    public AuthActionProcessor(String rawAuthAction){
        String[] aaSplit=rawAuthAction.split(aaSplitTag);
        action=Enum.valueOf(Action.class,aaSplit[0]);
        extraInfo=aaSplit[1];
        Log.i("AuthAction处理","action:"+action+" "+"extraInfo:"+extraInfo);
    }

    public Result getResult(){
        switch (action){
            case getSystemService:{
                switch (extraInfo){
                    case Context.CAMERA_SERVICE:{//调用Camera2API必备入口
                        return Result.Question;
                    }
                    case Context.LOCATION_SERVICE:{//调用定位必备入口
                        return Result.Question;
                    }
                    default:{
                        return Result.Granted;
                    }
                }
                //break;
            }
            case camera1Open:{
                return Result.Question;
                //break;
            }
            default:{//不太清楚，还是给用户提示吧
                return Result.Question;
            }
        }
    }
}
