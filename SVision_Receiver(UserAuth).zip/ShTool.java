package com.pvdnc.psvision.asynctest;


import com.pvdnc.psvision.asynctest.file.FileTool;

import java.io.File;
import java.io.InputStream;
import java.util.Random;

public class ShTool {

    private StringBuilder shSB;
    public ShTool(boolean isShFile/*说明是不是要保存为.sh文件*/){
        shSB=new StringBuilder();
        if(isShFile) shSB.append("#/system/bin/sh\n");
    }

    public void addShLine(String cmd){
        shSB.append(cmd).append("\n");
    }

    public String build(){
        return shSB.toString();
    }

    public boolean buildAsFile(String filePath) {
        try {
            byte[] fileData = shSB.toString().getBytes("utf-8");
            FileTool.saveByteArrayToFile(fileData, filePath, false);
            File file = new File(filePath);
            boolean isExecutable = file.setExecutable(true, false);
            boolean result = new File(filePath).exists();
            return (isExecutable && result);
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    public byte[] executeNow() throws Exception {
        String filePath= AppContext.getAppContext().getFilesDir().getAbsolutePath()+"/tempCmdLine_"+
                String.valueOf(new Random().nextInt(10*1000))+
                ".sh";
        if(!buildAsFile(filePath))throw new Exception("sh文件："+filePath+"创建失败");
        File file=new File(filePath);
        if(!file.canExecute())throw new Exception("sh文件："+filePath+" 不可执行");
        String[] cmdArray={"sh",filePath};
        byte[] resultData=shellExecute(cmdArray);
        file.delete();
        return resultData;
    }

    public static byte[] shellExecute(String[] cmdArray) throws Exception {
        Process process = Runtime.getRuntime().exec(cmdArray);
        int exitValue = process.waitFor();
        InputStream is = process.getInputStream();
        InputStream errorIs = process.getErrorStream();
        byte[] resultData = NetworkTool.readInputStream(is, true);
        byte[] errorData = NetworkTool.readInputStream(errorIs, true);
        if (0 != exitValue) {//命令执行时遇到错误
            //return errorData;
            throw new Exception("命令执行出错：\n"+new String(errorData,"utf-8"));
        } else {
            return resultData;
        }
    }
}
