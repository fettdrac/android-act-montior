package com.pvdnc.psvision.asynctest;

import android.app.Activity;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class UserAuthActivity extends Activity {
    private static final String TAG="";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_auth);
        setTitle("UserAuth");
        final String pkgName=getIntent().getStringExtra("pkgName");
        String authAction=getIntent().getStringExtra("authAction");
        TextView lblUAInfo=(TextView)findViewById(R.id.lblUAInfo);
        StringBuilder sb=new StringBuilder();
        sb.append("We received a userAuth request").append("\n");
        sb.append("pkgName:").append(pkgName).append("\n");
        sb.append("authAction:").append(authAction).append("\n");
        lblUAInfo.setText(sb.toString());
        EditText txtUAPassword=(EditText)findViewById(R.id.txtUAPassword);
        txtUAPassword.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                if(s.toString().contains("tc")){
                    canGrant=true;
                }else{
                    canGrant=false;
                }
            }
        });
        Button cmdUAGrant=(Button)findViewById(R.id.cmdUAGrant);
        cmdUAGrant.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                grant(pkgName,canGrant);
                finish();
            }
        });
        Button cmdUADeny=(Button)findViewById(R.id.cmdUADeny);
        cmdUADeny.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                deny(pkgName);
                finish();
            }
        });
    }

    private boolean canGrant;

    public static void grant(String pkgName,boolean canGrant){
        if(!canGrant)return;
        String result = "granted";//授权
        String uaFilePath = "/data/local/tmp/ua_" + pkgName;
        Log.e(TAG,"uaFilePath:"+uaFilePath);
        ShTool shTool = new ShTool(true);
        shTool.addShLine("su -c \"" +
                "echo \"" + result + "\"" + "> " + uaFilePath +
                "\"");
        shTool.addShLine("su -c \"" +
                "chmod 0755 " + uaFilePath +
                "\"");//改权限，让所有用户都可以读取
        try {
            shTool.executeNow();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void deny(String pkgName){
        String result = "deny";//拒绝
        String uaFilePath = "/data/local/tmp/ua_" + pkgName;
        Log.e(TAG,"uaFilePath:"+uaFilePath);
        ShTool shTool = new ShTool(true);
        shTool.addShLine("su -c \"" +
                "echo \"" + result + "\"" + "> " + uaFilePath +
                "\"");
        shTool.addShLine("su -c \"" +
                "chmod 0755 " + uaFilePath +
                "\"");//改权限，让所有用户都可以读取
        try {
            shTool.executeNow();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
