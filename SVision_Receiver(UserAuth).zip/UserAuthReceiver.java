package com.pvdnc.psvision.asynctest;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.util.Log;

public class UserAuthReceiver extends BroadcastReceiver {
    private static final String TAG="UserAuth广播";
    @Override
    public void onReceive(Context context, Intent intent) {

        String action = intent.getAction();
        String pkgName=intent.getStringExtra("pkgName");
        String authAction=intent.getStringExtra("authAction");
        Log.e(TAG, "已接收到"+action+"广播");
        Log.e(TAG,"pkgName:"+pkgName);
        Log.e(TAG,"authAction:"+authAction);
        if (action.equals("com.pvdnc.svision.userauth.response")) {
            ShTool shTool = new ShTool(true);
            shTool.addShLine("su -c \"" +
                    "rm " + authAction +
                    "\"");
            try {
                shTool.executeNow();
            } catch (Exception e) {
                e.printStackTrace();
            }
            return;
        }
        if (action.equals("com.pvdnc.svision.userauth.request")) {
            Intent aIntent=new Intent(AppContext.getAppContext(),UserAuthActivity.class);
            aIntent.putExtra("pkgName",pkgName);
            aIntent.putExtra("authAction",authAction);
            AuthActionProcessor aaProcessor=new AuthActionProcessor(authAction);
            switch (aaProcessor.getResult()){
                case Granted:{
                    UserAuthActivity.grant(pkgName,true);
                    break;
                }
                case Deny:{
                    UserAuthActivity.deny(pkgName);
                }
                case Question:{
                    aIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    AppContext.getAppContext().startActivity(aIntent);
                }
            }
            return;
        }
    }
}
