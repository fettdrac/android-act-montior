package com.pvdnc.psvision.asynctest.file;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

public class FileTool {
    public static byte[] getFileContent(String filePath) throws IOException {
        File file = new File(filePath);
        long fileSize = file.length();
        if (fileSize > Integer.MAX_VALUE) {
            throw new IOException("FILE IS TOO BIG");
        }
        FileInputStream fi = new FileInputStream(file);
        byte[] buffer = new byte[(int) fileSize];
        int offset = 0;
        int numRead = 0;
        while (offset < buffer.length
                && (numRead = fi.read(buffer, offset, buffer.length - offset)) >= 0) {
            offset += numRead;
        }
        // 确保所有数据均被读取
        if (offset != buffer.length) {
            throw new IOException("FOUND DATA LOST"
                    + file.getName());
        }
        fi.close();
        return buffer;
    }

    public static boolean saveByteArrayToFile(byte[] data, String filePath, boolean isAppend){
        File outputFile = new File(filePath);
        //文件不存在，建个新的（OS不能自己创建不存在的文件）
        if(!outputFile.exists()){
            try {
                outputFile.createNewFile();
            } catch (IOException e) {
                e.printStackTrace();
                return false;
            }
        }
        FileOutputStream outputFileStream = null;
        try {
            outputFileStream = new FileOutputStream(outputFile,isAppend);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
            return false;
        }
        try {
            outputFileStream.write(data,0,data.length);
        } catch (IOException e) {
            e.printStackTrace();
            return false;
        }
        try {
            outputFileStream.close();
        } catch (IOException e) {
            e.printStackTrace();
            return false;
        }
        return true;
    }

}
